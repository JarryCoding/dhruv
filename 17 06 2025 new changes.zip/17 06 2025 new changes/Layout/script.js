// Navbar highlight on scroll
 window.addEventListener('scroll', () => {
      const sections = document.querySelectorAll('section[id]');
      const links = document.querySelectorAll('.scroll-link');
      let current = '';
      sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (pageYOffset >= sectionTop - 120) {
          current = section.id;
        }
      });
      links.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
          link.classList.add('active');
        }
      });
    });

    // Smooth scroll on nav-link click
    document.querySelectorAll('.scroll-link').forEach(link => {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          window.scrollTo({
            top: target.offsetTop - 100,
            behavior: 'smooth'
          });
        }
      });
    });

// //function
function downloadBrochure() {
  // ceide here
}

function downloadPriceSheet() {
  // codeher
}

function submitContact(event) {
  event.preventDefault();
  alert("Thank you! We'll contact you shortly.");
}

  function toggleMobileForm() {
    const formBox = document.querySelector('.contact-form-fixed');
    formBox.classList.toggle('active');

    // toggle enquire close
    const btn = document.querySelector('.enquire-toggle');
    btn.textContent = formBox.classList.contains('active') ? 'Close' : 'Enquire Now';
  }

   function triggerEnquireNow() {
    const enquireBtn = document.querySelector('.enquire-toggle');
    if (enquireBtn) {
      enquireBtn.click(); // simulate button click
    }
  }


  
  // function submitContact(e) {
  //   e.preventDefault();
  //   alert("Form Submitted!");
    
  // }

  // function downloadPriceSheet() {
  //   alert("Download triggered!");
  //   // Your download logic here
  // }



// FAQ
// FAQ accordion 
document.querySelectorAll('.faq-accordion details').forEach((detail) => {
  detail.addEventListener('toggle', () => {
    if (detail.open) {
      // Close all other details when one is opened
      document.querySelectorAll('.faq-accordion details').forEach((otherDetail) => {
        if (otherDetail !== detail) {
          otherDetail.open = false;
        }
      });
    }
  });
});


// Sliders FP 
// tabs
    $(document).ready(function () {
      $('.slider1, .slider2').slick({
        dots: true,
        arrows: true,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 4000,
        speed: 500,
        slidesToShow: 1,
        adaptiveHeight: true
      });

      // Refresh on tab show
      $('button[data-bs-toggle="tab"]').on('shown.bs.tab', function () {
        $('.floor-slider').slick('setPosition');
        window.dispatchEvent(new Event('scroll')); // Update nav link highlight
      });
    });

    document.querySelectorAll('.tab-pane').forEach(tab => {
    const carousel = tab.querySelector('.carousel');
    const zoomInBtn = tab.querySelector('.zoom-in');
    const zoomOutBtn = tab.querySelector('.zoom-out');
    const zoomTargets = tab.querySelectorAll('.zoom-target');
    let zoomLevel = 1;
    const ZOOM_STEP = 0.25;
    const MAX_ZOOM = 2;
    const MIN_ZOOM = 1;
    const carouselInstance = bootstrap.Carousel.getOrCreateInstance(carousel);
    let resumeTimer = null;

    function applyZoom() {
      zoomTargets.forEach(img => {
        img.style.setProperty('--zoom', zoomLevel);
        if (zoomLevel > 1) {
          img.classList.add('zoomed');
        } else {
          img.classList.remove('zoomed');
        }
      });
    }

    function stopCarousel() {
      carouselInstance.pause();
      if (resumeTimer) clearTimeout(resumeTimer);
    }

    function restartCarousel() {
      if (zoomLevel === 1) {
        resumeTimer = setTimeout(() => {
          carouselInstance.cycle();
        }, 5000);
      }
    }

    zoomInBtn.addEventListener('click', () => {
      if (zoomLevel < MAX_ZOOM) {
        zoomLevel += ZOOM_STEP;
        stopCarousel();
        applyZoom();
      }
    });

    zoomOutBtn.addEventListener('click', () => {
      if (zoomLevel > MIN_ZOOM) {
        zoomLevel -= ZOOM_STEP;
        stopCarousel();
        applyZoom();
        if (zoomLevel === 1) restartCarousel();
      }
    });
  });
