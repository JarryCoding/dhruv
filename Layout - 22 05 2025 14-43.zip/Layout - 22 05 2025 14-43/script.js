function downloadBrochure() {
  // Replace with actual brochure file path
  const brochureLink = document.createElement('a');
  brochureLink.href = 'brochure.pdf';
  brochureLink.download = 'Project_Brochure.pdf';
  brochureLink.click();
}

function downloadPriceSheet() {
  // Replace with actual price sheet file path
  const priceSheetLink = document.createElement('a');
  priceSheetLink.href = 'pricesheet.pdf';
  priceSheetLink.download = 'Price_Sheet.pdf';
  priceSheetLink.click();
}

function submitContact(event) {
  event.preventDefault();
  alert("Thank you! We’ll contact you shortly.");
}
